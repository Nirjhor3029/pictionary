<?php
/**
 * Created by PhpStorm.
 * User: Sohel Rana
 * Date: 1/18/2019
 * Time: 2:50 AM
 */

echo "hello". session('status')." ". Auth::user()->name;

?>